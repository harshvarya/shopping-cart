package com.cdk.shopping_cart.chain;

import com.cdk.shopping_cart.discount.DiscountChain;
import org.junit.Assert;
import org.junit.Test;

public class DiscountChainTest {

    @Test
    public void testComputeDiscount1() {
        Double purchaseAmount = 15000.00;
        DiscountChain discountChain = DiscountChain.getChain();
        Double discount = discountChain.computeDiscount(purchaseAmount);
        Double billAmount = purchaseAmount - discount;
        Assert.assertTrue("mismatch result", billAmount.equals(13500.00));
    }

    @Test
    public void testComputeDiscount2() {
        Double purchaseAmount = 20000.00;
        DiscountChain discountChain = DiscountChain.getChain();
        Double discount = discountChain.computeDiscount(purchaseAmount);
        Double billAmount = purchaseAmount - discount;
        Assert.assertTrue("mismatch result", billAmount.equals(17500.00));
    }

    @Test
    public void testAddDiscount() {
        DiscountChain discountChain = DiscountChain.getChain();
        discountChain.addNewDiscount(20000.00, 50000.00, 30.00);
        Double purchaseAmount = 33000.00;
        Double discount = discountChain.computeDiscount(purchaseAmount);
        Double billAmount = purchaseAmount - discount;
        Assert.assertTrue("mismatch result", billAmount.equals(26600.00));
    }

    @Test
    public void testRemoveDiscount1() throws Exception {
        DiscountChain discountChain = DiscountChain.getChain();
        discountChain.removeOldDiscount(20000.00, 50000.00, 30.00);
        Double purchaseAmount = 32500.00;
        Double discount = discountChain.computeDiscount(purchaseAmount);
        Double billAmount = purchaseAmount - discount;
        Assert.assertTrue("mismatch result", billAmount.equals(30000.00));
    }

    @Test(expected = Exception.class)
    public void testRemoveDiscount2() throws Exception {
        DiscountChain discountChain = DiscountChain.getChain();
        discountChain.removeOldDiscount(20000.00, 50000.00, 40.00);
    }
}
