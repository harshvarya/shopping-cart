package com.cdk.shopping_cart.controller;

import com.cdk.shopping_cart.exception.DiscountException;
import com.cdk.shopping_cart.dto.ErrorResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.servlet.http.HttpServletRequest;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(DiscountException.class)
    public ResponseEntity<ErrorResponse> handleDiscountEx(HttpServletRequest request, Exception ex) {
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setErrorMessage(ex.getMessage());
        return new ResponseEntity<>(errorResponse, HttpStatus.OK);
    }
}
