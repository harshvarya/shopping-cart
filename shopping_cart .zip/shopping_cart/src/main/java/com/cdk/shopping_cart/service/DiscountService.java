package com.cdk.shopping_cart.service;

import com.cdk.shopping_cart.dto.DiscountResponse;

public interface DiscountService {

    public DiscountResponse applyDiscount(Double purchaseAmount);

    public void addNewDiscount(Double low, Double up, Double per);

    public void removeOldDiscount(Double low, Double up, Double per) throws Exception;

}
