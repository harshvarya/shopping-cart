package com.cdk.shopping_cart.service;

import com.cdk.shopping_cart.dto.DiscountDto;
import com.cdk.shopping_cart.dto.DiscountResponse;

public interface DiscountService {

    public DiscountResponse applyDiscount(Double purchaseAmount);

    public String addNewDiscount(Double low, Double up, Double per);

    public void removeOldDiscount(String id) throws Exception;

    public DiscountDto getDiscount(String id);

    public String getDiscounts();
}
