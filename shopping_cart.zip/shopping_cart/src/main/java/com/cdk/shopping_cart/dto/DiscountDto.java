package com.cdk.shopping_cart.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DiscountDto {

    @JsonProperty(required = true)
    private String percentage;

    @JsonProperty(required = true)
    private String lowerLimit;

    @JsonProperty(required = true)
    private String upperLimit;

    private String id;

    public String getLowerLimit() {
        return lowerLimit;
    }

    public void setLowerLimit(String lowerLimit) {
        this.lowerLimit = lowerLimit;
    }

    public String getPercentage() {
        return percentage;
    }

    public void setPercentage(String percentage) {
        this.percentage = percentage;
    }

    public String getUpperLimit() {
        return upperLimit;
    }

    public void setUpperLimit(String upperLimit) {
        this.upperLimit = upperLimit;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public DiscountDto(String lowerLimit, String percentage, String upperLimit) {
        this.lowerLimit = lowerLimit;
        this.percentage = percentage;
        this.upperLimit = upperLimit;
    }

    public DiscountDto() {

    }
}
