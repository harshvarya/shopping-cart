package com.cdk.shopping_cart.service.impl;

import com.cdk.shopping_cart.discount.DiscountChain;
import com.cdk.shopping_cart.dto.DiscountDto;
import com.cdk.shopping_cart.dto.DiscountResponse;
import com.cdk.shopping_cart.service.DiscountService;
import org.springframework.stereotype.Service;

@Service
public class DiscountServiceImpl implements DiscountService {

    private static DiscountChain discountChain = DiscountChain.getChain();

    @Override
    public DiscountResponse applyDiscount(Double purchaseAmount) {
        Double billAmount = purchaseAmount - discountChain.computeDiscount(purchaseAmount);
        return new DiscountResponse(purchaseAmount, billAmount);
    }

    @Override
    public String addNewDiscount(Double low, Double up, Double per) {
        return discountChain.addNewDiscount(low, up, per);
    }

    @Override
    public void removeOldDiscount(String id) throws Exception {
        discountChain.removeOldDiscount(id);
    }

    @Override
    public DiscountDto getDiscount(String id) {
        return discountChain.getDiscount(id);
    }

    @Override
    public String getDiscounts() {
        return discountChain.toString();
    }
}
