package com.cdk.shopping_cart.service.impl;

import com.cdk.shopping_cart.discount.DiscountChain;
import com.cdk.shopping_cart.dto.DiscountResponse;
import com.cdk.shopping_cart.service.DiscountService;
import org.springframework.stereotype.Service;

@Service
public class DiscountServiceImpl implements DiscountService {

    private static DiscountChain discountChain = DiscountChain.getChain();

    @Override
    public DiscountResponse applyDiscount(Double purchaseAmount) {
        Double billAmount = purchaseAmount - discountChain.computeDiscount(purchaseAmount);
        return new DiscountResponse(purchaseAmount, billAmount);
    }

    @Override
    public void addNewDiscount(Double low, Double up, Double per) {
        discountChain.addNewDiscount(low, up, per);
    }

    @Override
    public void removeOldDiscount(Double low, Double up, Double per) throws Exception {
        discountChain.removeOldDiscount(low, up, per);
    }
}
