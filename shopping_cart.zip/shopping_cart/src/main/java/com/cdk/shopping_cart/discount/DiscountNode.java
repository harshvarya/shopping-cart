package com.cdk.shopping_cart.discount;

import java.util.UUID;

/**
 * This class is used to implement 'Chain of Responsibility' design pattern.
 */
public class DiscountNode {

    private Double lowerLimit;
    private Double percentage;
    private Double upperLimit;
    private DiscountNode next;
    private String id;

    DiscountNode(Double low, Double up, Double per) {
        if (low != null) {
            lowerLimit = low;
        } else {
            lowerLimit = 0.0;
        }
        if (up != null) {
            upperLimit = up;
        } else {
            upperLimit = Double.MAX_VALUE;
        }
        percentage = per / 100;
        id =  UUID.randomUUID().toString();
    }

    void setNext(DiscountNode node) {
        next = node;
    }

    DiscountNode getNext() {
        return next;
    }

    boolean compare(Double lowerLimit, Double upperLimit, Double percentage) {
        if (this.upperLimit.compareTo(upperLimit) == 0
                && this.lowerLimit.compareTo(lowerLimit) == 0
                && this.percentage.compareTo(percentage) == 0) {
            return true;
        }
        return false;
    }

    Double compute(Double inputAmount) {
        if (inputAmount > lowerLimit) {
            Double currentDiscount = inputAmount;
            if (currentDiscount > upperLimit) {
                currentDiscount = upperLimit;
            }
            currentDiscount = (currentDiscount - lowerLimit) * percentage;
            if (next != null) {
                currentDiscount += next.compute(inputAmount);
            }
            return currentDiscount;
        }
        return 0.0;
    }

    String getId(){
        return id;
    }

    public Double getLowerLimit() {
        return lowerLimit;
    }

    public Double getPercentage() {
        return percentage;
    }

    public Double getUpperLimit() {
        return upperLimit;
    }

    @Override
    public String toString() {
        return "{" +
                "percentage='" + percentage + '\'' +
                ", lowerLimit='" + lowerLimit + '\'' +
                ", upperLimit='" + upperLimit + '\'' +
                ", id='" + id + '\'' +
                '}';
    }
}
