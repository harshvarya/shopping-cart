package com.cdk.shopping_cart.discount;

import java.io.Serializable;

/**
 * This class is based on 'Singleton' design pattern and 'Single Linked List' data structure
 */
public final class DiscountChain implements Serializable, Cloneable {

    private static final long serialVersionUID = 1234567890L;

    private static DiscountNode _head = new DiscountNode(0.00, 5000.00, 0.00);
    public static volatile DiscountChain _chain = new DiscountChain();

    private DiscountChain() {
        DiscountNode next1 = new DiscountNode(5000.00, 10000.00, 10.00);
        DiscountNode next2 = new DiscountNode(10000.00, 20000.00, 20.00);
        next1.setNext(next2);
        _head.setNext(next1);
    }

    public synchronized void addNewDiscount(Double low, Double up, Double per) {
        // if chain is empty
        if (_head == null) {
            _head = new DiscountNode(low, up, per);
            return;
        }
        // else travel to last node and add there
        DiscountNode current = _head;
        while (current.getNext() != null) {
            current = current.getNext();
        }
        current.setNext(new DiscountNode(low, up, per));
    }

    public synchronized void removeOldDiscount(Double low, Double up, Double per) throws Exception {
        DiscountNode current = _head;
        per /= 100.00;
        // If initial node matches
        if (current.compare(low, up, per)) {
            _head = current.getNext();
            current.setNext(null);
            return;
        }
        // If some other node matches
        DiscountNode previous = _head;
        current = current.getNext();
        while (current != null) {
            if (current.compare(low, up, per)) {
                previous.setNext(current.getNext());
                current.setNext(null);
                return;
            }
            previous = current;
            current = current.getNext();
        }
        throw new Exception("no such discount found");
    }

    public static DiscountChain getChain() {
        return _chain;
    }

    public synchronized double computeDiscount(Double purchaseAmount) {
        return _head.compute(purchaseAmount);
    }

    protected Object readResolve() {
        return _chain;
    }

    @Override
    public DiscountChain clone() {
        return _chain;
    }
}
