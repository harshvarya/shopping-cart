package com.cdk.shopping_cart.discount;

import com.cdk.shopping_cart.dto.DiscountDto;

import java.io.Serializable;

/**
 * This class is based on 'Singleton' design pattern and 'Single Linked List' data structure
 */
public final class DiscountChain implements Serializable, Cloneable {

    private static final long serialVersionUID = 1234567890L;

    private static DiscountNode _head = new DiscountNode(0.00, 5000.00, 0.00);
    public static volatile DiscountChain _chain = new DiscountChain();

    private DiscountChain() {
        DiscountNode next1 = new DiscountNode(5000.00, 10000.00, 10.00);
        DiscountNode next2 = new DiscountNode(10000.00, 20000.00, 20.00);
        next1.setNext(next2);
        _head.setNext(next1);
    }

    public synchronized String addNewDiscount(Double low, Double up, Double per) {
        // if chain is empty
        if (_head == null) {
            _head = new DiscountNode(low, up, per);
            return _head.getId();
        }
        // else travel to last node and add there
        DiscountNode current = _head;
        while (current.getNext() != null) {
            current = current.getNext();
        }
        DiscountNode newNode = new DiscountNode(low, up, per);
        current.setNext(newNode);
        return newNode.getId();
    }

    public synchronized void removeOldDiscount(String id) throws Exception {
        DiscountNode current = _head;
        // If initial node matches
        if (current.getId().equals(id)) {
            _head = current.getNext();
            current.setNext(null);
            return;
        }
        // If some other node matches
        DiscountNode previous = _head;
        current = current.getNext();
        while (current != null) {
            if (current.getId().equals(id)) {
                previous.setNext(current.getNext());
                current.setNext(null);
                return;
            }
            previous = current;
            current = current.getNext();
        }
        throw new Exception("no such discount found");
    }

    public static DiscountChain getChain() {
        return _chain;
    }

    public double computeDiscount(Double purchaseAmount) {
        return _head.compute(purchaseAmount);
    }

    public DiscountDto getDiscount(String id) {
        DiscountNode current = _head;
        while (current != null) {
            if (current.getId().equals(id)) {
                DiscountDto dto = new DiscountDto();
                dto.setId(current.getId());
                dto.setLowerLimit(current.getLowerLimit().toString());
                dto.setPercentage(current.getPercentage().toString());
                dto.setUpperLimit(current.getUpperLimit().toString());
                return  dto;
            }
            current = current.getNext();
        }
        return null;
    }

    protected Object readResolve() {
        return _chain;
    }

    @Override
    public DiscountChain clone() {
        return _chain;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        DiscountNode current = _head;
        sb.append("[");
        if(current!=null) {
            sb.append(current.toString());
        }
        current = current.getNext();
        while (current != null) {
            sb.append(",");
            sb.append(current.toString());
            current = current.getNext();
        }
        sb.append("]");
        return sb.toString();
    }
}
