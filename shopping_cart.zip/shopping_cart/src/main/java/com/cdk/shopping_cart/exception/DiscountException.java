package com.cdk.shopping_cart.exception;

public class DiscountException extends Exception {

    public DiscountException() {
        super();
    }

    public  DiscountException(String message) {
        super(message);
    }

    public DiscountException(String message, Throwable th) {
        super(message, th);
    }
}
