package com.cdk.shopping_cart.controller;

import com.cdk.shopping_cart.dto.DiscountDto;
import com.cdk.shopping_cart.dto.DiscountResponse;
import com.cdk.shopping_cart.exception.DiscountException;
import com.cdk.shopping_cart.service.DiscountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;

@RestController
@RequestMapping("/discount")
public class DiscountController {

    @Autowired
    DiscountService discountService;

    @GetMapping("/msg")
    public String getM() {
        return "Welcome to shopping-cart discount module !";
    }

    @GetMapping("/apply/{purchaseAmount}")
    public DiscountResponse apply(@PathVariable(value = "purchaseAmount", required = true) String purchaseAmount) throws DiscountException {
        try {
            Double purchaseAmt = Double.parseDouble(purchaseAmount);
            return discountService.applyDiscount(purchaseAmt);
        } catch (NumberFormatException ex) {
            throw new DiscountException("error while applying discount : " + ex.getMessage());
        }
    }

    @PostMapping("/")
    public ResponseEntity<DiscountDto> add(@RequestBody DiscountDto discount) throws DiscountException {
        try {
            Double lowerLimit = Double.parseDouble(discount.getLowerLimit());
            Double upperLimit = Double.parseDouble(discount.getUpperLimit());
            Double percentage = Double.parseDouble(discount.getPercentage());

            String id = discountService.addNewDiscount(lowerLimit, upperLimit, percentage);
            discount.setId(id);

            return new ResponseEntity<>(discount, HttpStatus.OK);
        } catch (NumberFormatException ex) {
            throw new DiscountException("error while adding a new discount : " + ex.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public void remove(@PathVariable String id) throws DiscountException {
        try {
            discountService.removeOldDiscount(id);
        } catch (Exception ex) {
            throw new DiscountException("error while removing an old discount : " + ex.getMessage());
        }
    }

    @GetMapping("/{id}")
    public DiscountDto getDiscount(@PathVariable String id) throws DiscountException{
        DiscountDto dto = discountService.getDiscount(id);
        if(Objects.isNull(dto)){
            throw new DiscountException("resource is not found with ID : "+id);
        }
        return dto;
    }

    @GetMapping("/")
    public String getDiscounts() throws DiscountException{
        return discountService.getDiscounts();
    }
}
