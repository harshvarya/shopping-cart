package com.cdk.shopping_cart.controller;

import com.cdk.shopping_cart.exception.DiscountException;
import com.cdk.shopping_cart.dto.DiscountDto;
import com.cdk.shopping_cart.dto.DiscountResponse;
import com.cdk.shopping_cart.service.DiscountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/discount")
public class DiscountController {

    @Autowired
    DiscountService discountService;

    @GetMapping("/msg")
    public String getM() {
        return "Welcome to shopping-cart discount module !";
    }

    @GetMapping("/apply/{purchaseAmount}")
    public DiscountResponse apply(@PathVariable(value = "purchaseAmount", required = true) String purchaseAmount) throws DiscountException {
        try {
            Double purchaseAmt = Double.parseDouble(purchaseAmount);
            return discountService.applyDiscount(purchaseAmt);
        } catch (NumberFormatException ex) {
            throw new DiscountException("error while applying discount : " + ex.getMessage());
        }
    }

    @PostMapping("/add")
    public ResponseEntity<String> add(@RequestBody DiscountDto discount) throws DiscountException {
        try {
            Double lowerLimit = Double.parseDouble(discount.getLowerLimit());
            Double upperLimit = Double.parseDouble(discount.getUpperLimit());
            Double percentage = Double.parseDouble(discount.getPercentage());

            discountService.addNewDiscount(lowerLimit, upperLimit, percentage);

            return new ResponseEntity<String>("New discount added successfully", HttpStatus.OK);
        } catch (NumberFormatException ex) {
            throw new DiscountException("error while adding a new discount : " + ex.getMessage());
        }
    }

    @PostMapping("/remove")
    public ResponseEntity<String> remove(@RequestBody DiscountDto discount) throws DiscountException {
        try {
            Double lowerLimit = Double.parseDouble(discount.getLowerLimit());
            Double upperLimit = Double.parseDouble(discount.getUpperLimit());
            Double percentage = Double.parseDouble(discount.getPercentage());

            discountService.removeOldDiscount(lowerLimit, upperLimit, percentage);

            return new ResponseEntity<String>("Old discount removed successfully", HttpStatus.OK);
        } catch (Exception ex) {
            throw new DiscountException("error while removing an old discount : " + ex.getMessage());
        }
    }
}
