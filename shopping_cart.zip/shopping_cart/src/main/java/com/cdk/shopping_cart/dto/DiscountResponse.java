package com.cdk.shopping_cart.dto;

public class DiscountResponse {

    private Double purchaseAmount;
    private Double billAmount;

    public Double getPurchaseAmount() {
        return purchaseAmount;
    }

    public void setPurchaseAmount(Double purchaseAmount) {
        this.purchaseAmount = purchaseAmount;
    }

    public Double getBillAmount() {
        return billAmount;
    }

    public void setBillAmount(Double billAmount) {
        this.billAmount = billAmount;
    }

    public DiscountResponse(Double purchaseAmount, Double billAmount) {
        this.purchaseAmount = purchaseAmount;
        this.billAmount = billAmount;
    }
}
