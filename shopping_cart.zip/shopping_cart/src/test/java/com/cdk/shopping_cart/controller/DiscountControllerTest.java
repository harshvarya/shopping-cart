package com.cdk.shopping_cart.controller;

import com.cdk.shopping_cart.dto.DiscountDto;
import com.cdk.shopping_cart.dto.ErrorResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class DiscountControllerTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @LocalServerPort
    private int port;

    private static volatile String resourceId;

    @Test
    public void test1() throws Exception {
        String response = restTemplate.getForObject("http://localhost:" + port + "/shopping-cart/discount/apply/15000.00",
                String.class);
        Assert.assertTrue("result mismatch", response.contains("{\"purchaseAmount\":15000.0,\"billAmount\":13500.0}"));
    }

    @Test
    public void test2() throws Exception {
        DiscountDto dto = new DiscountDto("20000.00", "30.00", "50000.00");
        HttpEntity<DiscountDto> request = new HttpEntity<>(dto);
        ResponseEntity<DiscountDto> responseEntity = restTemplate.postForEntity("http://localhost:" + port + "/shopping-cart/discount/",
                request, DiscountDto.class);
        Assert.assertTrue("result mismatch", responseEntity.getStatusCode() == HttpStatus.OK);
        resourceId = responseEntity.getBody().getId();
        Assert.assertNotNull("result mismatch", resourceId);
    }

    @Test
    public void test3() throws Exception {
        String response = restTemplate.getForObject("http://localhost:" + port + "/shopping-cart/discount/", String.class);
        Assert.assertNotNull("result mismatch", response.equals(response));
    }

    @Test
    public void test4() throws Exception {
        restTemplate.delete("http://localhost:" + port + "/shopping-cart/discount/" + resourceId);
        ResponseEntity<ErrorResponse> errResponse = restTemplate.getForEntity("http://localhost:" + port + "/shopping-cart/discount/" + resourceId, ErrorResponse.class);
        String expectedMessage = "resource is not found with ID : " + resourceId;
        Assert.assertTrue("result mismatch", errResponse.getStatusCode().equals(HttpStatus.BAD_REQUEST));
        Assert.assertTrue("result mismatch", errResponse.getBody().getErrorMessage().equals(expectedMessage));
    }
}
