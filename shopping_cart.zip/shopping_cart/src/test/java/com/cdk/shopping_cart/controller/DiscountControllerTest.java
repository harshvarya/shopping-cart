package com.cdk.shopping_cart.controller;

import com.cdk.shopping_cart.dto.DiscountDto;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class DiscountControllerTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @LocalServerPort
    private int port;

    @Test
    public void testApply() throws Exception {
        String response = this.restTemplate.getForObject("http://localhost:" + port + "/shopping-cart/discount/apply/15000.00",
                String.class);
        Assert.assertTrue("result mismatch", response.contains("{\"purchaseAmount\":15000.0,\"billAmount\":13500.0}"));
    }

    @Test
    public void testAdd() throws Exception {
        DiscountDto dto = new DiscountDto("20000.00", "30.00", "50000.00");
        HttpEntity<DiscountDto> request = new HttpEntity<>(dto);
        ResponseEntity<String> responseEntity = this.restTemplate.postForEntity("http://localhost:" + port + "/shopping-cart/discount/add",
                request, String.class);
        Assert.assertTrue("result mismatch", responseEntity.getStatusCode() == HttpStatus.OK);
        Assert.assertTrue("result mismatch", responseEntity.getBody().contains("New discount added successfully"));
    }

    @Test
    public void testRemove() throws Exception {
        DiscountDto dto = new DiscountDto("20000.00", "30.00", "50000.00");
        HttpEntity<DiscountDto> request = new HttpEntity<>(dto);
        ResponseEntity<String> responseEntity = this.restTemplate.postForEntity("http://localhost:" + port + "/shopping-cart/discount/remove",
                request, String.class);
        Assert.assertTrue("result mismatch", responseEntity.getStatusCode() == HttpStatus.OK);
        Assert.assertTrue("result mismatch", responseEntity.getBody().contains("Old discount removed successfully"));
    }
}
